package com.see.proxi.proxisee.ui.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainActivityViewModel : ViewModel() {
    private val majorNumber: MutableLiveData<String> = MutableLiveData()

    fun setMajorNumber(majorNumber: String) {
        if (majorNumber != this.majorNumber.value) {
            this.majorNumber.value = majorNumber
        }
    }

    fun getMajorNumber(): LiveData<String> {
        return majorNumber
    }
}
