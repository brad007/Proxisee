package com.see.proxi.proxisee.data.model

import android.location.Location
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "point_of_interest")
data class PointOfInterest(
        @PrimaryKey
        val majorNumber: Int,
        val minorNumber: Int,
        val beaconRange: Int,
        val text: String,
        val specialDirectionMax: List<Location>,
        val specialDirectionMin: List<Location>,
        val specialDirectionText: List<String>,
        val specialDirectionCode: List<Int>
)