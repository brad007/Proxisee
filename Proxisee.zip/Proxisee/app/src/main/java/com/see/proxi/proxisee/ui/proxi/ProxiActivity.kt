package com.see.proxi.proxisee.ui.proxi

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.github.pwittchen.swipe.library.rx2.Swipe
import com.github.pwittchen.swipe.library.rx2.SwipeEvent
import com.see.proxi.proxisee.R
import com.see.proxi.proxisee.ShakeDetector
import com.see.proxi.proxisee.data.model.SwipeData
import com.see.proxi.proxisee.data.remote.Api
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_proxi.*
import kotlinx.android.synthetic.main.content_proxi.*
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.ArrayList


class ProxiActivity : AppCompatActivity(),
        ShakeDetector.OnShakeListener,
        TextToSpeech.OnInitListener,
        LocationListener,
        SensorEventListener {
    override fun onSensorChanged(event: SensorEvent?) {
        val alpha = 0.97f

        synchronized(this) {
            if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
                for (i in 0..2)
                    gravity[i] = alpha * gravity[i] + (1 - alpha) * event.values[i]
            }

            if (event?.sensor?.type == Sensor.TYPE_MAGNETIC_FIELD) {
                for (i in 0..2)
                    geomagnetic[i] = alpha * geomagnetic[0] + (1 - alpha) * event.values[i]
            }

            val R = FloatArray(9)
            val I = FloatArray(9)

            val success = SensorManager.getRotationMatrix(R, I, gravity, geomagnetic)

            if (success) {
                val orientation = FloatArray(3)
                SensorManager.getOrientation(R, orientation)

                azimuth = Math.toDegrees(orientation[0].toDouble()).toFloat()
                azimuth = (azimuth + 360) % 360

                if (bearingDegrees != -1f) {
                    azimuth -= bearingDegrees
                }

                info_textview.text = azimuth.toString()
            }
        }
    }

    override fun onAccuracyChanged(p0: Sensor?, p1: Int) {
    }


    @SuppressLint("MissingPermission")


    override fun onResume() {
        super.onResume()
        sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
        sensorManager?.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        super.onPause()
        sensorManager?.unregisterListener(this)
    }

    override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {

    }

    override fun onProviderEnabled(p0: String?) {
    }

    override fun onProviderDisabled(p0: String?) {
    }

    private var heading: Float? = 0f

    override fun onLocationChanged(location: Location?) {
        val poi = viewModel.getPOI().value
        val maxLocations = poi?.specialDirectionMax!!
        val minLocations = poi.specialDirectionMin

        val size = maxLocations.size

        for(i in 0 until size){
            bearingDegreesMinArray[i] = location!!.bearingTo(minLocations[i])
            bearingDegreesMaxArray[i] = location.bearingTo(maxLocations[i])
        }
    }

    override fun onInit(p0: Int) {

    }


    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null
    private var gravity: FloatArray = FloatArray(3)
    private var geomagnetic: FloatArray = FloatArray(3)
    private var azimuth: Float = 0f
    private val correctAsimuth = 0f
    private val bearing: Boolean = false
    private var bearingDegrees = -1f
    private var bearingDegreesMinArray = ArrayList<Float>()
    private var bearingDegreesMaxArray = ArrayList<Float>()
    private var shakeDetector: ShakeDetector? = null


    private val disposable = CompositeDisposable()
    private val swipe: Swipe = Swipe()
    private val time = 600L
    private val api = Api()
    private lateinit var viewModel: ProxiViewModel
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_proxi)
        setSupportActionBar(toolbar)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magnetometer = sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        shakeDetector = ShakeDetector()
        shakeDetector?.setOnShakeListener(this)
        tts = TextToSpeech(this, this)
        tts?.language = Locale.US

        viewModel = ViewModelProviders.of(this).get(ProxiViewModel::class.java)

        val majorNumber = intent.getStringExtra("majorNumber")
        viewModel.setMajorNumber(majorNumber)

        viewModel.mutableEvent.observe(this, Observer {
            var text = if (it.numOfSwipes == 2) "DOUBLE_" else ""
            text += it.swipeEvent
            info_textview.text = text
        })

        viewModel.getMajorNumber().observe(this, Observer {
            api.getPOI(it)
                    .subscribe {
                        viewModel.setPOI(it.value)
                    }
        })


//        setupSwipe()

    }

    override fun onShake(count: Int) {
        if (count == 3) {
            handleShake()
        }
    }

    private fun handleShake() {
        val poi = viewModel.getPOI().value
        tts?.speak(poi?.text, TextToSpeech.QUEUE_FLUSH, null)
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
//        swipe.dispatchTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun setupSwipe() {
        disposable.add(swipe.observe()
                .subscribeOn(Schedulers.computation())
                .observeOn(AndroidSchedulers.mainThread())
                .filter {
                    it.toString() == SwipeEvent.SWIPED_UP.toString() || it.toString() == SwipeEvent.SWIPED_DOWN.toString()
                }
                .buffer(time, time, TimeUnit.MILLISECONDS)
                .subscribe({
                    if (it.size != 0) {
                        Log.v("MainActivity", "size: ${it.size}")
                        val swipeData = if (it.size > 1) {
                            SwipeData(it[0], 2)
                        } else {
                            SwipeData(it[0], 1)
                        }
                        viewModel.mutableEvent.postValue(swipeData)
                    }
                }, {
                    Log.v("MainActivity", "$it")
                }))
    }

}
