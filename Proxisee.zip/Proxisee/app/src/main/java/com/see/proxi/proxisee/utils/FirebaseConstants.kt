package com.see.proxi.proxisee.utils

object FirebaseConstants {
    const val POI_REF = "poi"
}