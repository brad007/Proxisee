package com.see.proxi.proxisee

import android.app.Application
import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.database.FirebaseDatabase
import com.polidea.rxandroidble2.RxBleClient
import com.polidea.rxandroidble2.internal.RxBleLog

class ProxiApplication : Application() {
    private lateinit var rxBleClient: RxBleClient

    companion object {
        fun getRxBleClient(context: Context): RxBleClient {
            val application = context.applicationContext as ProxiApplication
            return application.rxBleClient
        }
    }

    override fun onCreate() {
        super.onCreate()
        rxBleClient = RxBleClient.create(this)
        RxBleClient.setLogLevel(RxBleLog.VERBOSE)
        FirebaseApp.initializeApp(applicationContext)
//        FirebaseDatabase.getInstance().setPersistenceEnabled(true);
    }
}