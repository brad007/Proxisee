package com.see.proxi.proxisee.ui.main

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.os.*
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.polidea.rxandroidble2.RxBleClient
import com.see.proxi.proxisee.R
import com.see.proxi.proxisee.data.remote.Api
import com.see.proxi.proxisee.ui.proxi.ProxiActivity
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import org.altbeacon.beacon.*


class MainActivity : AppCompatActivity(), BeaconConsumer {
    override fun onBeaconServiceConnect() {
        val region = Region("myBeacons", null, null, null)
        beaconManager?.addMonitorNotifier(object : MonitorNotifier {
            override fun didDetermineStateForRegion(p0: Int, p1: Region?) {
                Log.v("MainActivity", "I have just switched from seeing/not seeing beacons: $p0, $p1")
            }

            override fun didEnterRegion(p0: Region?) {
                Log.v("MainActivity", "Enter")
                try {
                    beaconManager!!.startRangingBeaconsInRegion(region)
                } catch (e: RemoteException) {
                    e.printStackTrace()
                }
            }

            override fun didExitRegion(p0: Region?) {
                Log.v("MainActivity", "EXIT")
                try {
                    beaconManager!!.stopMonitoringBeaconsInRegion(region)
                } catch (e: RemoteException) {
                    e.printStackTrace()
                }
            }
        })

        beaconManager?.addRangeNotifier { p0, _ ->
            if (p0!!.isNotEmpty()) {

                val arrayList: ArrayList<String> = ArrayList()

                for (beacon in p0) {
                    try {
                        val major = beacon.id2.toString()
                        val index = major.indexOf(",")
                        Log.v("MainActivity", "major: $major index: $index")

                        arrayList.add(major)
                    } catch (e: IndexOutOfBoundsException) {

                    }

                }
                try {
                    viewModel.setMajorNumber(arrayList[1])
                } catch (e: java.lang.IndexOutOfBoundsException) {
                    //do nothing
                }

            } else {
                Log.v("MainActivity", "no beacons")
            }
        }

        try {
            beaconManager?.startMonitoringBeaconsInRegion(region)
        } catch (e: RemoteException) {
        }
    }

    private var beaconManager: BeaconManager? = null
    private lateinit var disposable: CompositeDisposable
    private var upEventInMillis: Long = 0L
    private var downEventInMillis: Long = 0L
    private var lastEvent: String? = null

    private lateinit var viewModel: MainActivityViewModel
    private lateinit var rxBleClient: RxBleClient
    private var scanDisposable: Disposable? = null
    private val api = Api()

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startActivity(Intent(this@MainActivity, ProxiActivity::class.java))
        viewModel = ViewModelProviders.of(this).get(MainActivityViewModel::class.java)
        disposable = CompositeDisposable()
        requestPermissions()
        promptUserForBluetooth()

        beaconManager = BeaconManager.getInstanceForApplication(this)
        beaconManager?.beaconParsers?.add(BeaconParser()
                .setBeaconLayout("s:0-1=feaa,m:2-2=00,p:3-3:-41,i:4-13,i:14-19"))
        beaconManager?.beaconParsers?.add(BeaconParser()
                .setBeaconLayout("s:0-1=feaa,m:2-2=10,p:3-3:-41,i:4-20v"))
        beaconManager?.beaconParsers?.add(BeaconParser()
                .setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24"))
        beaconManager?.beaconParsers?.add(BeaconParser()
                .setBeaconLayout("m:2-3=beac,i:4-19,i:20-21,i:22-23,p:24-24,d:25-25"))
        beaconManager?.bind(this)

        viewModel.getMajorNumber().observe(this, Observer {
            vibrateDevice()

            val intent = Intent(this@MainActivity, ProxiActivity::class.java)
            intent.putExtra("majorNumber", it)
            startActivity(intent)
        })
    }

    private fun vibrateDevice() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        // Vibrate for 500 milliseconds
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            //deprecated in API 26
            v.vibrate(500)
        }
    }


    private lateinit var rxPermissions: RxPermissions
    private fun requestPermissions() {
        rxPermissions = RxPermissions(this)
        val permission = rxPermissions.request(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.VIBRATE
        ).subscribe { granted ->
            if (granted) {
                //has location
            } else {
                //does not
            }
        }
        disposable.add(permission)
    }

    private fun promptUserForBluetooth() {
        val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
        val REQUEST_ENABLE_BT = 1
        startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)
    }

    override fun onPause() {
        super.onPause()
        if (!disposable.isDisposed) {
            disposable.clear()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}
