package com.see.proxi.proxisee.utils


fun getBearing(sourceLat: Double, sourceLong: Double, targetLat: Double, targetLong: Double): Double {
    val dLon = targetLong - sourceLong
    val y = Math.sin(dLon) * Math.cos(targetLat)
    val x = Math.cos(sourceLat) * Math.sin(targetLat) - Math.sin(sourceLat) * Math.cos(targetLat) * Math.cos(dLon)
    var brng = Math.toDegrees(Math.atan2(y, x))
    brng = 360 - (brng + 360) % 360
    return brng
}