package com.see.proxi.proxisee.ui.proxi

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.see.proxi.proxisee.data.model.PointOfInterest
import com.see.proxi.proxisee.data.model.SwipeData

class ProxiViewModel : ViewModel() {
    val mutableEvent: MutableLiveData<SwipeData> = MutableLiveData()
    private val pointOfInterest: MutableLiveData<PointOfInterest> = MutableLiveData()
    private val majorNumber: MutableLiveData<String> = MutableLiveData()

    fun setPOI(pointOfInterest: PointOfInterest?) {
        if (pointOfInterest != null && pointOfInterest != this.pointOfInterest.value) {
            this.pointOfInterest.value = pointOfInterest
        }
    }

    fun getPOI(): LiveData<PointOfInterest> {
        return pointOfInterest
    }

    fun setMajorNumber(majorNumber: String?) {
        if (majorNumber != null && majorNumber != this.majorNumber.value) {
            this.majorNumber.value = majorNumber
        }
    }

    fun getMajorNumber(): LiveData<String> {
        return majorNumber
    }
}